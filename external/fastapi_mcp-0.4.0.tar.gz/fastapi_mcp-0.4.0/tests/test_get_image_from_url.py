import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from fastapi.testclient import TestClient
import httpx

from examples.shared.apps.items import app


@pytest.fixture
def test_client():
    """Create a test client for the FastAPI app."""
    return TestClient(app)


@pytest.mark.asyncio
async def test_get_image_from_url(test_client):
    """Test the get_image_from_url endpoint."""
    # Mock the httpx client response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.content = b"fake_image_data"
    mock_response.headers = {"content-type": "image/jpeg"}
    mock_response.raise_for_status = MagicMock()

    # Mock the httpx AsyncClient
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client.get.return_value = mock_response

    # Patch the httpx.AsyncClient to use our mock
    with patch("httpx.AsyncClient", return_value=mock_client):
        # Call the endpoint with a test URL
        response = test_client.get("/image/?image_url=https://example.com/test.jpg")

    # Verify the response
    assert response.status_code == 200
    assert response.headers["content-type"] == "image/jpeg"
    assert response.content == b"fake_image_data"

    # Verify the mock was called correctly
    mock_client.get.assert_called_once_with("https://example.com/test.jpg", follow_redirects=True)


@pytest.mark.asyncio
async def test_get_image_from_url_error(test_client):
    """Test the get_image_from_url endpoint with an error response."""
    # Mock the httpx client to raise an exception
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client.get.side_effect = httpx.HTTPError("Error downloading image")

    # Patch the httpx.AsyncClient to use our mock
    with patch("httpx.AsyncClient", return_value=mock_client):
        # Call the endpoint with a test URL
        response = test_client.get("/image/?image_url=https://example.com/test.jpg")

    # Verify the response
    assert response.status_code == 500
    assert "Error downloading image" in response.json()["detail"]

    # Verify the mock was called correctly
    mock_client.get.assert_called_once_with("https://example.com/test.jpg", follow_redirects=True)
