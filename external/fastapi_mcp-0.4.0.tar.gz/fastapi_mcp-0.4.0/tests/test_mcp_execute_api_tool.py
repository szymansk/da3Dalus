import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from fastapi import FastAPI

from fastapi_mcp import FastApiMCP
from mcp.types import TextContent, ImageContent, EmbeddedResource, BlobResourceContents


@pytest.mark.asyncio
async def test_execute_api_tool_success(simple_fastapi_app: FastAPI):
    """Test successful execution of an API tool."""
    mcp = FastApiMCP(simple_fastapi_app)

    # Mock the HTTP client response
    mock_response = MagicMock()
    mock_response.json.return_value = {"id": 1, "name": "Test Item"}
    mock_response.status_code = 200
    mock_response.text = '{"id": 1, "name": "Test Item"}'
    mock_response.content = b'{"id": 1, "name": "Test Item"}'
    mock_response.headers = {"content-type": "application/json"}

    # Mock the HTTP client
    mock_client = AsyncMock()
    mock_client.get.return_value = mock_response

    # Test parameters
    tool_name = "get_item"
    arguments = {"item_id": 1}

    # Execute the tool
    with patch.object(mcp, "_http_client", mock_client):
        result = await mcp._execute_api_tool(
            client=mock_client, tool_name=tool_name, arguments=arguments, operation_map=mcp.operation_map
        )

    # Verify the result
    assert len(result) == 1
    assert isinstance(result[0], TextContent)
    assert result[0].text == '{\n  "id": 1,\n  "name": "Test Item"\n}'

    # Verify the HTTP client was called correctly
    mock_client.get.assert_called_once_with("/items/1", params={}, headers={})


@pytest.mark.asyncio
async def test_execute_api_tool_with_query_params(simple_fastapi_app: FastAPI):
    """Test execution of an API tool with query parameters."""
    mcp = FastApiMCP(simple_fastapi_app)

    # Mock the HTTP client response
    mock_response = MagicMock()
    mock_response.json.return_value = [{"id": 1, "name": "Item 1"}, {"id": 2, "name": "Item 2"}]
    mock_response.status_code = 200
    mock_response.text = '[{"id": 1, "name": "Item 1"}, {"id": 2, "name": "Item 2"}]'
    mock_response.content = b'[{"id": 1, "name": "Item 1"}, {"id": 2, "name": "Item 2"}]'
    mock_response.headers = {"content-type": "application/json"}

    # Mock the HTTP client
    mock_client = AsyncMock()
    mock_client.get.return_value = mock_response

    # Test parameters
    tool_name = "list_items"
    arguments = {"skip": 0, "limit": 2}

    # Execute the tool
    with patch.object(mcp, "_http_client", mock_client):
        result = await mcp._execute_api_tool(
            client=mock_client, tool_name=tool_name, arguments=arguments, operation_map=mcp.operation_map
        )

    # Verify the result
    assert len(result) == 1
    assert isinstance(result[0], TextContent)

    # Verify the HTTP client was called with query parameters
    mock_client.get.assert_called_once_with("/items/", params={"skip": 0, "limit": 2}, headers={})


@pytest.mark.asyncio
async def test_execute_api_tool_with_body(simple_fastapi_app: FastAPI):
    """Test execution of an API tool with request body."""
    mcp = FastApiMCP(simple_fastapi_app)

    # Mock the HTTP client response
    mock_response = MagicMock()
    mock_response.json.return_value = {"id": 1, "name": "New Item"}
    mock_response.status_code = 200
    mock_response.text = '{"id": 1, "name": "New Item"}'
    mock_response.content = b'{"id": 1, "name": "New Item"}'
    mock_response.headers = {"content-type": "application/json"}

    # Mock the HTTP client
    mock_client = AsyncMock()
    mock_client.post.return_value = mock_response

    # Test parameters
    tool_name = "create_item"
    arguments = {
        "item": {"id": 1, "name": "New Item", "price": 10.0, "tags": ["tag1"], "description": "New item description"}
    }

    # Execute the tool
    with patch.object(mcp, "_http_client", mock_client):
        result = await mcp._execute_api_tool(
            client=mock_client, tool_name=tool_name, arguments=arguments, operation_map=mcp.operation_map
        )

    # Verify the result
    assert len(result) == 1
    assert isinstance(result[0], TextContent)

    # Verify the HTTP client was called with the request body
    mock_client.post.assert_called_once_with("/items/", params={}, headers={}, json=arguments)


@pytest.mark.asyncio
async def test_execute_api_tool_with_non_ascii_chars(simple_fastapi_app: FastAPI):
    """Test execution of an API tool with non-ASCII characters."""
    mcp = FastApiMCP(simple_fastapi_app)

    # Test data with both ASCII and non-ASCII characters
    test_data = {
        "id": 1,
        "name": "你好 World",  # Chinese characters + ASCII
        "price": 10.0,
        "tags": ["tag1", "标签2"],  # Chinese characters in tags
        "description": "这是一个测试描述",  # All Chinese characters
    }

    # Mock the HTTP client response
    mock_response = MagicMock()
    mock_response.json.return_value = test_data
    mock_response.status_code = 200
    mock_response.text = (
        '{"id": 1, "name": "你好 World", "price": 10.0, "tags": ["tag1", "标签2"], "description": "这是一个测试描述"}'
    )
    mock_response.content = b'{"id": 1, "name": "\xe4\xbd\xa0\xe5\xa5\xbd World", "price": 10.0, "tags": ["tag1", "\xe6\xa0\x87\xe7\xad\xbe2"], "description": "\xe8\xbf\x99\xe6\x98\xaf\xe4\xb8\x80\xe4\xb8\xaa\xe6\xb5\x8b\xe8\xaf\x95\xe6\x8f\x8f\xe8\xbf\xb0"}'
    mock_response.headers = {"content-type": "application/json"}

    # Mock the HTTP client
    mock_client = AsyncMock()
    mock_client.get.return_value = mock_response

    # Test parameters
    tool_name = "get_item"
    arguments = {"item_id": 1}

    # Execute the tool
    with patch.object(mcp, "_http_client", mock_client):
        result = await mcp._execute_api_tool(
            client=mock_client, tool_name=tool_name, arguments=arguments, operation_map=mcp.operation_map
        )

    # Verify the result
    assert len(result) == 1
    assert isinstance(result[0], TextContent)

    # Verify that the response contains both ASCII and non-ASCII characters
    response_text = result[0].text
    assert "你好" in response_text  # Chinese characters preserved
    assert "World" in response_text  # ASCII characters preserved
    assert "标签2" in response_text  # Chinese characters in tags preserved
    assert "这是一个测试描述" in response_text  # All Chinese description preserved

    # Verify the HTTP client was called correctly
    mock_client.get.assert_called_once_with("/items/1", params={}, headers={})


@pytest.mark.asyncio
async def test_execute_api_tool_with_image_response(simple_fastapi_app: FastAPI):
    """Test execution of an API tool that returns an image."""
    mcp = FastApiMCP(simple_fastapi_app)

    # Mock the HTTP client response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.content = b"fake_image_data"
    mock_response.headers = {"content-type": "image/jpeg"}

    # Mock the HTTP client
    mock_client = AsyncMock()
    mock_client.get.return_value = mock_response

    # Test parameters
    tool_name = "get_item_image"
    arguments = {"item_id": 1}

    # Create a custom operation map with the image tool
    custom_operation_map = {
        **mcp.operation_map,
        "get_item_image": {
            "path": "/items/{item_id}/image",
            "method": "get",
            "parameters": [{"in": "path", "name": "item_id"}],
        },
    }

    # Execute the tool
    with patch.object(mcp, "_http_client", mock_client):
        result = await mcp._execute_api_tool(
            client=mock_client, tool_name=tool_name, arguments=arguments, operation_map=custom_operation_map
        )

    # Verify the result
    assert len(result) == 1
    assert isinstance(result[0], ImageContent)
    assert result[0].type == "image"
    assert result[0].mimeType == "image/jpeg"

    # Verify base64 encoding
    import base64

    expected_data = base64.b64encode(b"fake_image_data").decode("utf-8")
    assert result[0].data == expected_data

    # Verify the HTTP client was called correctly
    mock_client.get.assert_called_once_with("/items/1/image", params={}, headers={})


@pytest.mark.asyncio
async def test_execute_api_tool_with_embedded_resource(simple_fastapi_app: FastAPI):
    """Test execution of an API tool that returns an embedded resource."""
    mcp = FastApiMCP(simple_fastapi_app)

    # Mock the HTTP client response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.content = b"fake_binary_data"
    mock_response.headers = {
        "content-type": "application/octet-stream",
        "content-disposition": "attachment; filename=data.bin",
    }

    # Mock the HTTP client
    mock_client = AsyncMock()
    mock_client.get.return_value = mock_response

    # Test parameters
    tool_name = "get_item_binary"
    arguments = {"item_id": 1}

    # Create a custom operation map with the binary tool
    custom_operation_map = {
        **mcp.operation_map,
        "get_item_binary": {
            "path": "/items/{item_id}/binary",
            "method": "get",
            "parameters": [{"in": "path", "name": "item_id"}],
        },
    }

    # Execute the tool
    with patch.object(mcp, "_http_client", mock_client):
        result = await mcp._execute_api_tool(
            client=mock_client, tool_name=tool_name, arguments=arguments, operation_map=custom_operation_map
        )

    # Verify the result
    assert len(result) == 1
    assert isinstance(result[0], EmbeddedResource)
    assert result[0].type == "resource"
    assert isinstance(result[0].resource, BlobResourceContents)
    assert result[0].resource.mimeType == "application/octet-stream"

    # Verify base64 encoding
    import base64

    expected_data = base64.b64encode(b"fake_binary_data").decode("utf-8")
    assert result[0].resource.blob == expected_data

    # Verify the HTTP client was called correctly
    mock_client.get.assert_called_once_with("/items/1/binary", params={}, headers={})
