import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from fastapi.testclient import TestClient
import httpx

from examples.shared.apps.items import app


@pytest.fixture
def test_client():
    """Create a test client for the FastAPI app."""
    return TestClient(app)


@pytest.mark.asyncio
async def test_get_resource_from_url(test_client):
    """Test the get_resource_from_url endpoint."""
    # Mock the httpx client response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.content = b"fake_resource_data"
    mock_response.headers = {"content-type": "application/octet-stream"}
    mock_response.raise_for_status = MagicMock()

    # Mock the httpx AsyncClient
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client.get.return_value = mock_response

    # Patch the httpx.AsyncClient to use our mock
    with patch("httpx.AsyncClient", return_value=mock_client):
        # Call the endpoint with a test URL
        response = test_client.get("/resource/?resource_url=https://example.com/test.bin")

    # Verify the response
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/octet-stream"
    assert response.content == b"fake_resource_data"

    # Verify the mock was called correctly
    mock_client.get.assert_called_once_with("https://example.com/test.bin", follow_redirects=True)


@pytest.mark.asyncio
async def test_get_resource_from_url_with_content_disposition(test_client):
    """Test the get_resource_from_url endpoint with content-disposition header."""
    # Mock the httpx client response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.content = b"fake_resource_data"
    mock_response.headers = {
        "content-type": "application/octet-stream",
        "content-disposition": "attachment; filename=test.bin",
    }
    mock_response.raise_for_status = MagicMock()

    # Mock the httpx AsyncClient
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client.get.return_value = mock_response

    # Patch the httpx.AsyncClient to use our mock
    with patch("httpx.AsyncClient", return_value=mock_client):
        # Call the endpoint with a test URL
        response = test_client.get("/resource/?resource_url=https://example.com/test.bin")

    # Verify the response
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/octet-stream"
    assert response.headers["content-disposition"] == "attachment; filename=test.bin"
    assert response.content == b"fake_resource_data"

    # Verify the mock was called correctly
    mock_client.get.assert_called_once_with("https://example.com/test.bin", follow_redirects=True)


@pytest.mark.asyncio
async def test_get_resource_from_url_error(test_client):
    """Test the get_resource_from_url endpoint with an error response."""
    # Mock the httpx client to raise an exception
    mock_client = AsyncMock()
    mock_client.__aenter__.return_value = mock_client
    mock_client.__aexit__.return_value = None
    mock_client.get.side_effect = httpx.HTTPError("Error downloading resource")

    # Patch the httpx.AsyncClient to use our mock
    with patch("httpx.AsyncClient", return_value=mock_client):
        # Call the endpoint with a test URL
        response = test_client.get("/resource/?resource_url=https://example.com/test.bin")

    # Verify the response
    assert response.status_code == 500
    assert "Error downloading resource" in response.json()["detail"]

    # Verify the mock was called correctly
    mock_client.get.assert_called_once_with("https://example.com/test.bin", follow_redirects=True)
